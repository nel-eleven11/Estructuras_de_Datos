hoja de trabajo 4 de estructuras de datos
